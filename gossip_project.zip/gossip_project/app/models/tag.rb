class Tag < ApplicationRecord
	has_many :gossips
end
